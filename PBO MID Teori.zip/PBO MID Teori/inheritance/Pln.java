class Pln{
	public String nama;
	public String alamat;
	public int meteran;
	public int harga,tipe;
	public int bayar;
	
	
}
